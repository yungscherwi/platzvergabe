/* 
Script für den Algorithmus in der Anonymen Platzverteilung 
 */

$(document).ready(function(){                                                   //nachdem DOM geladen wurde, auszuführender Code
   
            var student = [                                                     //bsp.: studentenarray
                [21432425, "Ricky", "Chan", "Wiinf"],
                [21452523, "Jerome", "Kallisch", "Wiinf"],
                [11521342, "Leon", "Scherweit", "wiinf"],
                [21415152, "Mona", "Briesemeister", "Wipäd"],
                [21515313, "Lukas", "Tezel", "Wiinf"],
                [11258466, "Max", "Müller", "Wiinf"],
                [21385421, "Lisa", "Blume", "BWL"]
                ];

    //script um ne html tabelle in einen array umzuwandeln
            var myTableArray = [];                                              //array aus der htmltabelle
               
               $("#tablebsp").each(function() {                                 //"tablebsp" ist die ID in der html tabelle (müssten für die Hörsäle noch hinzugefügt werden)
                   var arrayOfThisRow = [];                                     
                   var tableData = $(this).find('td');                          
                   if (tableData.length > 0) {
                       tableData.each(function() { 
                           arrayOfThisRow.push($(this).text()); 
                       });
                       myTableArray.push(arrayOfThisRow);
                   }
               });
              
          //  try {  
                for (var i = 0; i < myTableArray[0].length; i++) {              //loop für die verfügbaren Plätze im Hörsaal
                    if (myTableArray[0][i].includes("Platz")) {                 //sobald in der td das Keyword "Platz" erscheint -> True
                        var temptabelle = myTableArray[0][i];                   
                  
                        for (var j = 0; j <= temptabelle.length; j++) {         //loop für die Studentenliste
                            var c = j+1;                                        //damit die Platzbeschreibung mit 1 anfängt, nicht bei 0
                            myTableArray [0][i] = "Platz "+ c +": "+ student [j][0];        //neuer Array mit den belegten Plätzen
                            console.log(myTableArray[0][i]);
                            }                           
                        }     
                    // else {
                } 
 
       /*    } catch (err) {
               // document.getElementById("tablebsp").innerHTML = err.message;
               }*/
});